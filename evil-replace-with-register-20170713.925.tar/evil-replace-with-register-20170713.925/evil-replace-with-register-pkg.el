;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-replace-with-register" "20170713.925"
  "Port of vim plugin ReplaceWithRegister."
  '((evil "1.0.8"))
  :url "https://github.com/Dewdrops/evil-ReplaceWithRegister"
  :commit "91cc7bf21a94703c441cc9212214075b226b7f67"
  :revdesc "91cc7bf21a94"
  :keywords '("evil" "plugin")
  :authors '(("Dewdrops" . "v_v_4474@126.com"))
  :maintainers '(("Dewdrops" . "v_v_4474@126.com")))
