;;; evil-collection-rtags.el --- Evil bindings for `rtags' -*- lexical-binding: t -*-

;; Copyright (C) 2017 James Nguyen

;; Author: James Nguyen <james@jojojames.com>
;; Maintainer: James Nguyen <james@jojojames.com>
;; Pierre Neidhardt <mail@ambrevar.xyz>
;; URL: https://github.com/emacs-evil/evil-collection
;; Version: 0.0.1
;; Package-Requires: ((emacs "29.1"))
;; Keywords: evil, rtags, tools

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:
;;; Evil bindings for `rtags'.

;;; Code:
(require 'evil-collection)
(require 'rtags nil t)

(defvar rtags-mode-map)
(defvar rtags-dependency-tree-mode-map)
(defvar rtags-references-tree-mode-map)
(defvar rtags-location-stack-visualize-mode-map)

(defconst evil-collection-rtags-maps '(rtags-mode-map
                                       rtags-dependency-tree-mode-map
                                       rtags-references-tree-mode-map
                                       rtags-location-stack-visualize-mode-map))

;;;###autoload
(defun evil-collection-rtags-setup ()
  "Set up `evil' bindings for `rtags'."
  (evil-set-initial-state 'rtags-mode 'normal)
  (evil-set-initial-state 'rtags-dependency-tree-mode 'normal)
  (evil-set-initial-state 'rtags-references-tree-mode 'normal)
  (evil-set-initial-state 'rtags-location-stack-visualize-mode 'normal)

  (evil-collection-define-key 'normal 'rtags-mode-map
    [mouse-1] 'rtags-select-other-window
    [mouse-2] 'rtags-select-other-window

    "c" 'rtags-select-caller
    "C" 'rtags-select-caller-other-window)
  (evil-collection-bind 'rtags-mode-map
                        'action 'rtags-select
                        'action-other 'rtags-select-other-window
                        'action-stay 'rtags-show-in-other-window
                        'quit 'rtags-call-bury-or-delete
                        'delete 'rtags-select-and-remove-rtags-buffer
                        'delete-2 'rtags-select-and-remove-rtags-buffer)

  (evil-collection-bind 'rtags-dependency-tree-mode-map 'section-toggle 'rtags-dependency-tree-toggle-current-expanded)
  (evil-collection-define-key 'normal 'rtags-dependency-tree-mode-map
    "E" 'rtags-dependency-tree-expand-all
    "c" 'rtags-dependency-tree-collapse-all
    "-" 'rtags-dependency-tree-collapse-current
    "+" 'rtags-dependency-tree-expand-current
    "P" 'rtags-dependency-tree-find-path

    [mouse-1] 'rtags-select-other-window
    [mouse-2] 'rtags-select-other-window
    "s" 'rtags-show-in-other-window)
  (evil-collection-bind 'rtags-dependency-tree-mode-map
                        'action 'rtags-select
                        'action-other 'rtags-select-other-window
                        'action-stay 'rtags-show-in-other-window
                        'next-item 'rtags-dependency-tree-next-level
                        'prev-item 'rtags-dependency-tree-previous-level
                        'next-section 'rtags-dependency-tree-next-level
                        'prev-section 'rtags-dependency-tree-previous-level
                        'quit 'rtags-call-bury-or-delete
                        'find-file 'rtags-dependency-tree-find-path
                        'delete 'rtags-select-and-remove-rtags-buffer
                        'delete-2 'rtags-select-and-remove-rtags-buffer)

  (evil-collection-bind 'rtags-references-tree-mode-map 'section-toggle 'rtags-references-tree-toggle-current-expanded)
  (evil-collection-define-key 'normal 'rtags-references-tree-mode-map
    "E" 'rtags-references-tree-expand-all
    "c" 'rtags-references-tree-collapse-all
    "-" 'rtags-references-tree-collapse-current
    "+" 'rtags-references-tree-expand-current

    [mouse-1] 'rtags-select-other-window
    [mouse-2] 'rtags-select-other-window
    "s" 'rtags-show-in-other-window)
  (evil-collection-bind 'rtags-references-tree-mode-map
                        'action 'rtags-select
                        'action-other 'rtags-select-other-window
                        'action-stay 'rtags-show-in-other-window
                        'next-item 'rtags-references-tree-next-level
                        'prev-item 'rtags-references-tree-previous-level
                        'next-section 'rtags-references-tree-next-level
                        'prev-section 'rtags-references-tree-previous-level
                        'quit 'rtags-call-bury-or-delete
                        'delete 'rtags-select-and-remove-rtags-buffer
                        'delete-2 'rtags-select-and-remove-rtags-buffer)

  (evil-collection-define-key 'normal 'rtags-location-stack-visualize-mode-map
    [mouse-1] 'rtags-select-other-window
    [mouse-2] 'rtags-select-other-window
    "s" 'rtags-show-in-other-window)
  (evil-collection-bind 'rtags-location-stack-visualize-mode-map
                        'action 'rtags-select
                        'action-other 'rtags-select-other-window
                        'action-stay 'rtags-show-in-other-window
                        'quit 'rtags-call-bury-or-delete
                        'delete 'rtags-select-and-remove-rtags-buffer
                        'delete-2 'rtags-select-and-remove-rtags-buffer))

(provide 'evil-collection-rtags)
;;; evil-collection-rtags.el ends here
