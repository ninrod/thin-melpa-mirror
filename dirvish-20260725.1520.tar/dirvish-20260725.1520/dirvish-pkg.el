;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20260725.1520"
  "A modern file manager based on dired mode."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "bf164ee21e128837ede59be03836a9900c4a41be"
  :revdesc "bf164ee21e12"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
